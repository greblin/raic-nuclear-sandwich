class Ownership:
    ALLY = 1
    ENEMY = 2
